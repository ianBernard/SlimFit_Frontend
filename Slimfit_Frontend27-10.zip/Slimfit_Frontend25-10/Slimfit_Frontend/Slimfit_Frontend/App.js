import * as React from 'react';
import React,{useState, useEffect} from 'react'
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, TextInput, TouchableOpacity, onPress, ActivityIndicator, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useEffect, useState } from 'react'


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function IniciarScreen({ navigation }) {
  const [usuario, setusuario]=useState('Usuario')
  const [contraseña, setcontraseña]=useState('Contraseña')
  const [lista, setlista] =useState([])
  useEffect(()=> {getListaUsuario()},[])
  const getListaUsuario=()=>{
    fetch('http://localhost:4000/usuarios',{
      method: GET,
      headers:{
        "Content-Type": "application/json"
      }
    }).then(res=>{
      return res.json()
    }).then(res=>{
      var data=res.Usarios
      setList(data)
    }).catch(err=>{
      console.log(err)
    })
  }
  return (
    <View style={styles.container}>
      <View
        style={{
          backgroundColor: "white",
          width: 350,
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}
      />
      <View
        style={{
          backgroundColor: "#DA4343",
          width: 350,
          height: 300,
          position: 'absolute'
        }}
      />
      <Text style={styles.titulo}>SlimFit</Text>
      <Image source={require('./assets/App/logo.jpg')} style={styles.logo} />
      <TextInput
        style={{
          top: 400,
          width: 300,
          alignSelf: "center",
          textAlign: "center",
          position: 'absolute',
          borderWidth: 3,
          height: 50,
          fontWeight: "bold",
          borderColor: '#DA4343'
        }}
        name="Usuario"
        placeholder="Username"
        placeholderTextColor="#DA4343"
        keyboardType="default"
        onChange={(val)=>setusuario(val)}
      />
      
      <TextInput
        secureTextEntry={true}
        style={{
          top: 500,
          width: 300,
          textAlign: "center",
          position: 'absolute',
          borderWidth: 3,
          height: 50,
          fontWeight: "bold",
          borderColor: "#DA4343"
        }}
        name="Password"
        placeholder="Password"
        placeholderTextColor="#DA4343"
        keyboardType="default"
        onChange={(val)=>setcontraseña(val)}
      />
            <Text>Usuario: {usuario}, contraseña: {contraseña}</Text>

      <TouchableOpacity
        style={styles.button1}
        onPress={() => navigation.navigate('Posts')}
      >
        
        <Text style={{
          fontSize: 16,
          color: "white",
          top: "25%"
        }}>Iniciar Sesion</Text>
        
       
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button2}
        onPress={onPress}
      >
        <Text style={{
          fontSize: 16,
          color: "white",
          top: "25%"
        }}>Registrarse</Text>
      </TouchableOpacity>
      <StatusBar style="auto" />
    </View>
  );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function PostsScreen({ navigation }) {
  let [isLoading, setIsLoading] = useState();
  let [error, setError] = useState();
  let [response, setResponse] = useState();

  useEffect(() => {
    fetch("http://10.152.2.99:4000/usuarios/")
      .then((res) => res.json())
      .then((result) => {
        setIsLoading(false);
        setResponse(result);
      })
      .catch((error) => {
        console.log("error");
        setIsLoading(false);
        setError(error);
      });
  })
  const getContent = () => {
    if (isLoading) {
      return <ActivityIndicator size="large" />;
    }

    if (error) {
      return <Text>(error)</Text>
    }

    console.log(response);
    return <Text>API Called</Text>
  };


  return (
    <View style={styles.container}>          
      <View
        style={{
          backgroundColor: "white",
          width: 350,
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}>
        {getContent()}
        
      </View>
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Posts')}><Image source={require('./assets/App/IconoHome.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoBuscar.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Crear')}><Image source={require('./assets/App/IconoCrear.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoUsuario.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoNotificacion.png')} style={styles.iconobarra}></Image></TouchableOpacity>
      </View>
    </View>
  );
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CrearScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View
        style={{
          backgroundColor: "white",
          width: 350,
          height: "100%",
          flex: 1,
          position: 'absolute'
        }}>
        <View style={{ backgroundColor: "#E3E3E3", height: 250, alignItems: "center", justifyContent: "center" }}>
          <TouchableOpacity><Image style={{
            resizeMode: "contain",
            height: 70,
            width: 70
          }} source={require('./assets/App/DefaultImage.png')} />
            <Text style={{ position: "absolute", alignSelf:"center", top:75
           }}>Haz click para agregar imagen</Text>
          </TouchableOpacity>
        </View>
        <Text style={{alignSelf:"center", fontWeight:"bold", fontSize:18, top:5}}>Tipo de Publicación</Text>
        <TouchableOpacity>
          <View style={{backgroundColor:"#DA4343", width:"45%", alignItems:"center", justifyContent:"center", height:50, top:15, right:-10}}>
            <Text style={{fontSize:20, fontWeight:"bold", color:"#ffffff"}}>Receta</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
        <View style={{backgroundColor:"#DA4343", width:"45%", alignItems:"center", justifyContent:"center", height:50, top:-35, right:10, position:"absolute"}}>
            <Text style={{fontSize:20, fontWeight:"bold", color:"#ffffff"}}>Rutina</Text>
          </View>
        </TouchableOpacity>
        <TextInput
        style={{
          top: 350,
          height:100,
          width: 300,
          alignSelf:"center",
          position: 'absolute',
          borderWidth: 3,
          justifyContent: "flex-start",
          multiline: true,
          fontWeight: "bold",
          borderColor: "#DA4343"
        }}
        placeholder="Descripción"
        placeholderTextColor="#DA4343"
        keyboardType="default"
      />
      </View>
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Posts')}><Image source={require('./assets/App/IconoHome.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoBuscar.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo} onPress={() => navigation.navigate('Crear')}><Image source={require('./assets/App/IconoCrear.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoUsuario.png')} style={styles.iconobarra}></Image></TouchableOpacity>
        <TouchableOpacity style={styles.BarradeAbajo}><Image source={require('./assets/App/IconoNotificacion.png')} style={styles.iconobarra}></Image></TouchableOpacity>
      </View>
    </View>
  )
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const Stack = createNativeStackNavigator();

function App() {

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Iniciar" component={IniciarScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Posts" component={PostsScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Crear" component={CrearScreen} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const styles = StyleSheet.create({
  titulo: {
    position: 'absolute',
    top: 245,
    alignSelf: "center",
    color: "white",
    fontWeight: "bold",
    fontSize: 40
  },
  container: {
    flex: 1,
    backgroundColor: '#c4c4c4',
    alignItems: 'center',
  },
  barradebusqueda: {
    backgroundColor: '#CFCFCF',
    height: 20,
    width: '100%',
    alignSelf: 'flex-end',
    alignItems: 'center',
  },
  logo: {
    flex: 1,
    width: 220,
    height: 220,
    position: 'absolute',
    top: 30,
    left: 70,
    resizeMode: 'contain'
  },
  iconobarra: {
    alignSelf: 'center',
    height: 35,
    width: 35,
    position: 'relative'
  },
  button1: {
    alignItems: "center",
    backgroundColor: "#43B6DA",
    position: 'absolute',
    height: 50,
    width: 300,
    top: 750,
    alignSelf: 'center',
  },
  button2: {
    alignItems: "center",
    backgroundColor: "#43B6DA",
    position: 'absolute',
    height: 50,
    width: 300,
    top: 670,
    alignSelf: 'center',

  },
  bottomBar: {
    backgroundColor: "#CFCFCF",
    width: "100%",
    height: 65,
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-evenly',

  },
  BarradeAbajo: {
    bottom: -14
  }
});
export default App;
